/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment1;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Assignment1 {
    String name;
    String surname;
    String username;
    String password;
    int phone_num;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner userIn = new Scanner (System.in);
       System.out.print("Enter your name:      ");
       String name = userIn.nextLine();
       
        System.out.print("Enter your surname:   ");
        String surname = userIn.nextLine();
        System.out.print("Create your username: ");
        String username = userIn.nextLine();
        System.out.print("Create a password:    ");
        String password = userIn.nextLine();
        System.out.print("Enter your phone number:");
        int phone_num = userIn.nextInt();
        
    }
    
}
